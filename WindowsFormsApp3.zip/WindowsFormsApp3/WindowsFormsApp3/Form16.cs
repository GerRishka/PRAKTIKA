﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form16 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form16()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }
        private void LoadData()
        {
            string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
            string query = "SELECT * FROM Books";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Books (BookID, Title, Author, YearPublished, Genre, AvailableCopies) " +
                        "VALUES (@ID, @Title,@Author, @YearPublished, @Genre, @AvailableCopies)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Title", textBox2.Text);
                    command.Parameters.AddWithValue("@Author", textBox3.Text);
                    command.Parameters.AddWithValue("@YearPublished", textBox4.Text);
                    command.Parameters.AddWithValue("@Genre", textBox5.Text);
                    command.Parameters.AddWithValue("@AvailableCopies", Int32.Parse(textBox6.Text));


                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Books (BookID, Title, Author, YearPublished, Genre, AvailableCopies) " +
                        "VALUES (@ID, @Title,@Author, @YearPublished, @Genre, @AvailableCopies)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Title", textBox2.Text);
                    command.Parameters.AddWithValue("@Author", textBox3.Text);
                    command.Parameters.AddWithValue("@YearPublished", textBox4.Text);
                    command.Parameters.AddWithValue("@Genre", textBox5.Text);
                    command.Parameters.AddWithValue("@AvailableCopies", Int32.Parse(textBox6.Text));


                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Books SET Title = @Title, Author = @Author, YearPublished = @YearPublished, Genre = @Genre, AvailableCopies = @AvailableCopies WHERE BookID = @ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Title", textBox2.Text);
                    command.Parameters.AddWithValue("@Author", textBox3.Text);
                    command.Parameters.AddWithValue("@YearPublished", textBox4.Text);
                    command.Parameters.AddWithValue("@Genre", textBox5.Text);
                    command.Parameters.AddWithValue("@AvailableCopies", Int32.Parse(textBox6.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
