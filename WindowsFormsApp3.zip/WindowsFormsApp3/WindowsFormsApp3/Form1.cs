﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        private string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
        public string UserRole { get; private set; }
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;

            textBox2.PasswordChar = '*';
        }
        public bool AuthenticateUser(string login, string password)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT UserID, Name, Role FROM Users WHERE Login = @Login AND Password = @Password";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Login", login);
                        command.Parameters.AddWithValue("@Password", password);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                UserRole = reader["Role"].ToString();
                                return true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }

            return false;
        }
        private void label1_Click(object sender, EventArgs e)
        {
       
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Пожалуйста, введите логин и пароль.");
                return;
            }

            if (AuthenticateUser(login, password))
            {
                switch (UserRole)
                {
                    case "admin":
                        OpenForm(new Form3());
                        break;
                    case "Читатель":
                        OpenForm(new Form4());
                        break;
                    case "Библиотекарь":
                        OpenForm(new Form5());
                        break;
                    default:
                        MessageBox.Show("У вас нет доступа к системе.");
                        break;
                }
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        }
        private void OpenForm(Form form)
        {
            form.Show();
            this.Hide();
        }
    }
}
