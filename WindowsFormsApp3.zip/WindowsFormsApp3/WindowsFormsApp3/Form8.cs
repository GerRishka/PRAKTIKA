﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp3
{
    public partial class Form8 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form8()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void LoadData()
        {
            string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
            string query = "SELECT * FROM BorrowRequests";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO BorrowRequests (RequestID, UserID, BookID, RequestDate, DueDate, ReturnDate, Status) " +
                    "VALUES (@ID, @UserID,@BookID, @Email, @RequestDate, @DueDate, @RegistrationDate, @Status)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@BookID", Int32.Parse(textBox4.Text));
                    command.Parameters.AddWithValue("@RequestDate", dateTimePicker2.Value.Date);
                    command.Parameters.AddWithValue("@DueDate", dateTimePicker1.Value.Date);
                    command.Parameters.AddWithValue("@ReturnDate", dateTimePicker3.Value.Date);
                    command.Parameters.AddWithValue("@Status", Int32.Parse(textBox7.Text));


                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM BorrowRequests WHERE RequestID = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", Int32.Parse(textBox1.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            string query = "UPDATE BorrowRequests SET UserID = @UserID, BookID = @BookID, RequestDate = @RequestDate, DueDate = @DueDate,ReturnDate = @ReturnDate,Status =@Status, WHERE RequestID = @ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@BookID", Int32.Parse(textBox4.Text));
                    command.Parameters.AddWithValue("@RequestDate", dateTimePicker1.Value.Date);
                    command.Parameters.AddWithValue("@DueDate", dateTimePicker2.Value.Date);
                    command.Parameters.AddWithValue("@ReturnDate", dateTimePicker3.Value.Date);
                    command.Parameters.AddWithValue("@Status", Int32.Parse(textBox7.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void button4_Click(object sender, EventArgs e)
        {
          
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void Form8_Load(object sender, EventArgs e)
        {

        }
    }
}
