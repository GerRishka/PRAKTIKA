﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form17 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form17()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }
        private void LoadData()
        {
            string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
            string query = "SELECT * FROM Notifications";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Notifications (NotificationID, UserID, Message, SentDate) " +
                    "VALUES (@ID, @UserID,@Message, @SentDate)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@Message", textBox4.Text);
                    command.Parameters.AddWithValue("@SentDate", dateTimePicker1.Value.Date);



                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Notifications WHERE NotificationID = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", Int32.Parse(textBox1.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Notifications SET UserID = @UserID, Message = @Message, SentDate = @SentDate WHERE NotificationID = @ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@Message", textBox4.Text);
                    command.Parameters.AddWithValue("@SentDate", dateTimePicker1.Value.Date);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }
    }
}
