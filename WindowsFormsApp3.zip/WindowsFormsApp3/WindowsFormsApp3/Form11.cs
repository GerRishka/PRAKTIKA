﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp3
{
    public partial class Form11 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form11()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }
        private void LoadData()
        {
            string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
            string query = "SELECT * FROM Employees";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Employees (EmployeeID, UserID, Position, PhoneNumber, Email) " +
                       "VALUES (@ID, @UserID,@Position, @PhoneNumber, @Email)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@Position", textBox3.Text);
                    command.Parameters.AddWithValue("@PhoneNumber", textBox4.Text);
                    command.Parameters.AddWithValue("@Email", textBox5.Text);


                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Employees WHERE EmployeeID = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", Int32.Parse(textBox1.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Employees SET UserID = @UserID, Position = @Position, PhoneNumber = @PhoneNumber, Email = @Email WHERE EmployeeID = @ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@Position", textBox3.Text);
                    command.Parameters.AddWithValue("@PhoneNumber", textBox4.Text);
                    command.Parameters.AddWithValue("@Email", textBox5.Text);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }
    }
}
