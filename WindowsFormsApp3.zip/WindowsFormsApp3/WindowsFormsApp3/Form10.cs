﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form10 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form10()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }
        private void LoadData()
        {
            string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
            string query = "SELECT * FROM Fines";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {

            string query = "INSERT INTO Fines (FineID, UserID, RequestID, Amount,Paid, IssuedDate) " +
                    "VALUES (@ID, @UserID,@RequestID, @Amount, @Paid, @IssuedDate)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@RequestID", Int32.Parse(textBox4.Text));
                    command.Parameters.AddWithValue("@Amount", textBox5.Text);
                    command.Parameters.AddWithValue("@Paid", textBox7.Text);
                    command.Parameters.AddWithValue("@IssuedDate", dateTimePicker1.Value.Date);



                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Fines WHERE FineID = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", Int32.Parse(textBox1.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Fines SET UserID = @UserID, RequestID = @RequestID, Amount = @Amount, Paid=@Paid,@IssuedDate=IssuedDate  WHERE FineID = @ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@UserID", Int32.Parse(textBox2.Text));
                    command.Parameters.AddWithValue("@RequestID", Int32.Parse(textBox4.Text));
                    command.Parameters.AddWithValue("@Amount", textBox5.Text);
                    command.Parameters.AddWithValue("@Paid", textBox7.Text);
                    command.Parameters.AddWithValue("@IssuedDate", dateTimePicker1.Value.Date);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 form = new Form5();
            form.Show();
            this.Hide();
        }
    }
}
