﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form6 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form6()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }
        private void LoadData()
        {
            string query = "SELECT * FROM Books";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
            }
        private void pictureBox1_Click(object sender, EventArgs e)
        {


        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Books (BookID, Title, Author, YearPublished, Genre, AvailableCopies) " +
                         "VALUES (@ID, @Title,@Author, @YearPublished, @Genre, @AvailableCopies)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Title", textBox2.Text);
                    command.Parameters.AddWithValue("@Author", textBox3.Text);
                    command.Parameters.AddWithValue("@YearPublished", textBox4.Text);
                    command.Parameters.AddWithValue("@Genre", textBox5.Text);
                    command.Parameters.AddWithValue("@AvailableCopies", Int32.Parse(textBox6.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Books WHERE BookID = @Id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", Int32.Parse(textBox1.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Books SET Title = @Title, Author = @Author, YearPublished = @YearPublished, Genre = @Genre, AvailableCopies = @AvailableCopies WHERE BookID = @ID";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@ID", Int32.Parse(textBox1.Text));
                    command.Parameters.AddWithValue("@Title", textBox2.Text);
                    command.Parameters.AddWithValue("@Author", textBox3.Text);
                    command.Parameters.AddWithValue("@YearPublished", textBox4.Text);
                    command.Parameters.AddWithValue("@Genre", textBox5.Text);
                    command.Parameters.AddWithValue("@AvailableCopies", Int32.Parse(textBox6.Text));

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            LoadData();
        }

        private void выходToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
          
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void выходToolStripMenuItem_Click_2(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }
    }
}
