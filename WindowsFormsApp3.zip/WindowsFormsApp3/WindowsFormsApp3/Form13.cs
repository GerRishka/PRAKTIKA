﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp3
{
    public partial class Form13 : Form
    {
        string connectionString = @" Data Source= KATHOME; Initial catalog=praktika; Integrated Security=True";
        public Form13()
        {
            InitializeComponent();
            LoadData();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.AutoScaleMode = AutoScaleMode.Font;
            this.AutoSize = true;
        }
        private void LoadData()
        {
            string connectionString = @"Data Source=KATHOME; Initial Catalog=praktika; Integrated Security=True";
            string query = "SELECT * FROM Fines";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);

                DataTable table = new DataTable();
                adapter.Fill(table);

                dataGridView1.DataSource = table;
            }
        }
        private void назадToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Hide();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string baseQuery = "SELECT * FROM Fines WHERE 1=1"; // Базовый запрос
            List<string> conditions = new List<string>(); // Условие для фильтра
            List<SqlParameter> parameters = new List<SqlParameter>(); // Параметры запроса

            // Добавляем условия, если соответствующие поля заполнены
            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                conditions.Add("UserID = @UserID");
                parameters.Add(new SqlParameter("@UserID", textBox2.Text));
            }
            if (dateTimePicker1.Value != DateTime.MinValue)
            {
                conditions.Add("IssuedDate = @IssuedDate");
                parameters.Add(new SqlParameter("@IssuedDate", dateTimePicker1.Value.Date));
            }

            // Собираем полный запрос с условиями
            string query = conditions.Count > 0 ? $"{baseQuery} AND {string.Join(" AND ", conditions)}" : baseQuery;

            // Выполняем запрос и заполняем DataGridView
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Добавляем параметры в команду
                    command.Parameters.AddRange(parameters.ToArray());

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    dataGridView1.DataSource = table; // Отображение данных в DataGridView
                }
            }
        }

        private void обновитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
