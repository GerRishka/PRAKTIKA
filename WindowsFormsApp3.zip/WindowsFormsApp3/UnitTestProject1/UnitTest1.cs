﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WindowsFormsApp3;
using System.Data;
using System.Windows.Forms;


namespace WindowsFormsApp3.Tests
{
    [TestClass]
    public class Form1Tests
    {
        private Form1 form;
        private Form6 form1;

        [TestInitialize]
        public void Setup()
        {
            form = new Form1();
            form1 = new Form6();
        }

        [TestMethod]
        public void Test_SuccessfulAdminAuthentication()
        {
            
            string login = "admin";
            string password = "admin123";

           
            bool result = form.AuthenticateUser(login, password);

            
            Assert.IsTrue(result);
            Assert.AreEqual("admin", form.UserRole);
        }

        [TestMethod]
        public void Test_SuccessfulReaderAuthentication()
        {
           
            string login = "user";
            string password = "456";

            
            bool result = form.AuthenticateUser(login, password);

         
            Assert.IsTrue(result);
            Assert.AreEqual("Читатель", form.UserRole);
        }

        [TestMethod]
        public void Test_SuccessfulLibrarianAuthentication()
        {
          
            string login = "bool";
            string password = "123";

            
            bool result = form.AuthenticateUser(login, password);

            
            Assert.IsTrue(result);
            Assert.AreEqual("Библиотекарь", form.UserRole);
        }

        [TestMethod]
        public void Test_FailedAuthenticationDueToIncorrectPassword()
        {
           
            string login = "admin";
            string password = "1234";

            bool result = form.AuthenticateUser(login, password);

            
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Test_FailedAuthenticationDueToIncorrectLogin()
        {
          
            string login = "wrongLogin";
            string password = "admin1234";

            bool result = form.AuthenticateUser(login, password);

    
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void Test_FailedAuthenticationDueToEmptyLogin()
        {
        
            string login = "";
            string password = "admin123";

            bool result = form.AuthenticateUser(login, password);

            Assert.IsFalse(result);
        }

        [TestMethod]
        public void Test_FailedAuthenticationDueToEmptyPassword()
        {
  
            string login = "admin";
            string password = "";

            bool result = form.AuthenticateUser(login, password);
            Assert.IsFalse(result);
        }
        [TestMethod]
        public void Test_FormBorderStyle_IsFixedSingle()
        {

            var borderStyle = form.FormBorderStyle;

            Assert.AreEqual(FormBorderStyle.FixedSingle, borderStyle);
        }
        [TestMethod]
        public void Test_AuthenticateUser_LongPassword_ReturnsFalse()
        {
    
            string login = "admin";
            string password = new string('a', 1000);

            bool result = form.AuthenticateUser(login, password);

            Assert.IsFalse(result);
        }
        [TestMethod]
        public void Test_AuthenticateUser_LongLogin_ReturnsFalse()
        {
       
            string login = new string('a', 1000);
            string password = "admin123";

            bool result = form.AuthenticateUser(login, password);

            Assert.IsFalse(result);
        }
    }
}
